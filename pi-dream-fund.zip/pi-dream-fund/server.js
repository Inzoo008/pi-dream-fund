const express = require('express');
const cors = require('cors');
const app = express();
const port = 3000;

app.use(cors());
app.use(express.json());

let dreams = [
  { id: 1, title: 'Start a Bakery', description: 'I want to open a small bakery in my town.', goal: 1000 },
  { id: 2, title: 'Learn Coding', description: 'I want to learn full-stack development.', goal: 500 },
];

// Get all dreams
app.get('/api/dreams', (req, res) => {
  res.json(dreams);
});

// Add a new dream
app.post('/api/dreams', (req, res) => {
  const newDream = {
    id: dreams.length + 1,
    title: req.body.title,
    description: req.body.description,
    goal: req.body.goal,
  };
  dreams.push(newDream);
  res.json(newDream);
});

app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});