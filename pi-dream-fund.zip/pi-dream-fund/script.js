document.addEventListener('DOMContentLoaded', () => {
  const dreamForm = document.getElementById('dream-form');
  const dreamList = document.getElementById('dream-list');

  // Fetch and display dreams
  fetch('/api/dreams')
    .then(response => response.json())
    .then(data => {
      data.forEach(dream => {
        const dreamCard = document.createElement('div');
        dreamCard.className = 'dream-card';
        dreamCard.innerHTML = `
          <h3>${dream.title}</h3>
          <p>${dream.description}</p>
          <p><strong>Goal:</strong> ${dream.goal} Pi</p>
        `;
        dreamList.appendChild(dreamCard);
      });
    });

  // Handle dream submission
  dreamForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const title = document.getElementById('dream-title').value;
    const description = document.getElementById('dream-description').value;
    const goal = document.getElementById('dream-goal').value;

    fetch('/api/dreams', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ title, description, goal }),
    })
      .then(response => response.json())
      .then(data => {
        alert('Dream submitted successfully!');
        dreamForm.reset();
      })
      .catch(error => {
        console.error('Error:', error);
      });
  });
});